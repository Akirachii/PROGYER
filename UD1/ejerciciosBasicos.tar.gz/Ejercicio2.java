// Pau gra <3
public class Ejercicio2 {
    public static void main(String[] args) {
        double a=8.0;
        int b=3;
        char c='5';


        int calculo1;
        double calculo2;

        calculo1 = (int)(a - b + c);
        calculo2 = (a - b + c);
        System.out.println("a - b + c = "+(a - b + c)+ " calculo1 = "+calculo1+" calculo2 = "+calculo2);

    }
}
