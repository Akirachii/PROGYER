// pau gra <3

public class Ejercicio1 {
    public static void main(String[] args) {
        int x = 129;
        int y = 83;

        int suma = (x+y);
        int resta=(x-y);
        double division=(x%y);
        double producto=(x/y);

        System.out.println("Esta es la suma: " + suma);
        System.out.println("Esta es la resta: " + resta);
        System.out.println("Esta es la division: " + division);
        System.out.println("Esta es la producto: " + producto);

    }

}
